Before opening the project, some configuration must be done so that the QR code can be shown, and Database must be configured in MySQL.

For QR Code to show properly:
Open XAMPP Control Panel > From Apache Module, click on Config > PHP.ini > Open with Notepad > Ctrl+F to search for ;extension=gd > Remove the ; in front of the ;extension=gd > Ctrl+S to save and then quit

*Generated QR code images are saved in the 'qrcodes' folder.

For the website's database
Drag and drop the MiniProjectFile to htdocs folder inside XAMPP Explorer > Open the Database folder and export the mini_project.sql to phpmyadmin. (Database name in phpmyadmin must be the same with the exported sql file.)


